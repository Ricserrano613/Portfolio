function setup() {
  createCanvas(400,400);
}

function draw() {
  background(255,100,100); 
  fill("orange");
  ellipse(380,200,80,80);
  fill("green");
  rect(0,300,400,100);
  line(50,200,300,10);  
  line(80,150,250,10);
  line(80,100,200,10);
}